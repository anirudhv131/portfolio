# Price Efficiency and Resolution Capture in Decentralized Prediction Markets

Replication materials: paper, data-collection scripts, analysis code, and figures.

## What this is
A study of Polymarket prediction markets arguing that a prediction market has two
parts: a trading layer that sets the price, and a resolution layer that decides the
outcome. The trading layer self-corrects and is well calibrated; the resolution layer
is settled by a token-weighted vote and is not protected by the same forces.

## Pipeline (run in order)

### Data collection (public Polymarket APIs, no key required)
- `code/fetch_polymarket.py` — pulls the highest-volume resolved markets (questions,
  resolution rules, outcomes, volume) into `pm_data/pm_markets.csv`.
- `code/fetch_prices.py` — pulls each market's price ~24h before close, for calibration.
- `code/fetch_holders.py` — pulls the top holders of each market (Data API).

Run each with: `pip install requests pandas` then `python <script>.py`.

### Analysis (run after data collection)
- `code/01_ambiguity.py` — builds the resolution-rule ambiguity index; locates the
  documented capture cases in the ambiguity distribution.
- `code/02_fig_ambiguity.py` — Figure: ambiguity distribution with capture cases marked.
- `code/03_calibration.py` — calibration curve, Brier score, skill vs base rate.
- `code/04_favlongshot_and_categories.py` — favorite-longshot regression; ambiguity by
  category.
- `code/05_holder_concentration.py` — exploratory holder-concentration analysis.

Note: the analysis scripts reference local input paths (e.g. the uploaded CSVs). Edit the
file paths at the top of each script to point at your copy of the data before running.

## Figures
`figures/` contains the four figures used in the paper:
calibration, favorite-longshot residuals, ambiguity distribution, ambiguity by category.

## Data sources (all public)
- Polymarket Gamma API: https://gamma-api.polymarket.com
- Polymarket CLOB price history: https://clob.polymarket.com
- Polymarket Data API (holders): https://data-api.polymarket.com

## Honest limitations
The conflict-of-interest channel (whether dispute voters held positions) is documented
through reporting, not measured, because the UMA vote records needed to measure it
directly were not freely available. The calibration sample covers the 201 markets with
retrievable order-book history. The ambiguity comparison rests on four documented cases
and is illustrative rather than a powered test.

## License
Released for academic and educational use.
