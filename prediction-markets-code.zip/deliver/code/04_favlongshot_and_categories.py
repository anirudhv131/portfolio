import pandas as pd, numpy as np, json, re
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---------- load ----------
mk = pd.read_csv("pm_scored.csv")
pr = pd.read_csv("/mnt/user-data/uploads/pm_prices_snapshot.csv")
for c in ["yes_won","p_24h_before","p_7d_before"]:
    pr[c] = pd.to_numeric(pr[c], errors="coerce")
pr["p_pre"] = pr["p_24h_before"].fillna(pr["p_7d_before"])
d = pr.dropna(subset=["p_pre","yes_won"]).copy()

# ---------- (1) favorite-longshot via calibration regression ----------
x = d["p_pre"].values; y = d["yes_won"].values
n = len(x)
b, a = np.polyfit(x, y, 1)              # y = a + b x
yhat = a + b*x
resid = y - yhat
sigma2 = np.sum(resid**2)/(n-2)
sxx = np.sum((x-x.mean())**2)
se_b = np.sqrt(sigma2/sxx)
se_a = np.sqrt(sigma2*(1/n + x.mean()**2/sxx))
print("=== favorite-longshot calibration regression  (realized = a + b*price) ===")
print(f" N={n}")
print(f" intercept a = {a:.3f}  (SE {se_a:.3f})   [perfect=0]")
print(f" slope     b = {b:.3f}  (SE {se_b:.3f})   [perfect=1]")
print(f" t(slope=1) = {(b-1)/se_b:.2f}")
# FL interpretation: slope<1 with positive intercept => longshots overpriced, favorites underpriced
print()

# ---------- (2) ambiguity by category ----------
def cat(q):
    s=str(q).lower()
    if re.search(r"trump|biden|election|president|senate|congress|governor|vote|democrat|republican|poll|nominee|cabinet|supreme court|war|ukraine|russia|israel|gaza|zelensky|putin", s): return "Politics/Geo"
    if re.search(r"bitcoin|btc|ethereum|eth|crypto|coin|token|solana|microstrategy|nft|defi", s): return "Crypto"
    if re.search(r"\bnba\b|\bnfl\b|super bowl|premier league|world cup|champions|ufc|f1|soccer|football|playoff|finals|cup|match|wins the", s): return "Sports"
    if re.search(r"fed|inflation|gdp|rate|jobs|unemploy|cpi|recession|stock|s&p|nasdaq|earnings|economy", s): return "Economics"
    return "Other"
mk["category"]=mk["question"].apply(cat)
catg = mk.groupby("category").agg(n=("ambiguity","size"),
        ambiguity=("ambiguity","mean"), subj_share=("subj", lambda s:(s>=1).mean())).sort_values("ambiguity")
print("=== ambiguity by category ===")
for c,r in catg.iterrows():
    print(f"  {c:14s} n={int(r['n']):5d}  mean ambiguity={r['ambiguity']:.2f}  subj-language share={r['subj_share']:.0%}")
print()

# ---------- descriptive stats for a table ----------
print("=== dataset descriptives ===")
print("N markets:", len(mk))
print("total volume $bn:", round(mk['volumeNum'].sum()/1e9,1))
print("median volume $:", int(mk['volumeNum'].median()))
print("yes base rate:", round(mk['yes_won'].mean(),3))
print("mean ambiguity:", round(mk['ambiguity'].mean(),2))
print("subjective-language share:", round((mk['subj']>=1).mean(),3))

# ---------- figure 3: favorite-longshot residual ----------
fig, ax = plt.subplots(figsize=(6.8,4.4), dpi=150)
bins=np.linspace(0,1,11); d["bx"]=pd.cut(d["p_pre"],bins,right=False)
gg=d.groupby("bx",observed=True).agg(pred=("p_pre","mean"),real=("yes_won","mean"),n=("yes_won","size")).reset_index()
gg["gap"]=gg["real"]-gg["pred"]
ax.axhline(0,color="#888",ls="--",lw=1)
ax.bar(gg["pred"],gg["gap"],width=0.07,color=np.where(gg["gap"]>=0,"#3a6ea5","#d1495b"),edgecolor="white")
ax.set_xlabel("Market price (implied probability)",fontsize=10)
ax.set_ylabel("Realized − priced",fontsize=10)
ax.set_title("Favorite–longshot residuals",fontsize=12,fontweight="bold",loc="left",pad=8)
ax.text(0.02,0.95,f"slope b={b:.2f} (perfect=1)\nintercept a={a:.2f} (perfect=0)",
        transform=ax.transAxes,va="top",fontsize=8.5,
        bbox=dict(boxstyle="round,pad=0.3",fc="#eef2f7",ec="#bcc"))
for s in ["top","right"]: ax.spines[s].set_visible(False)
plt.figtext(0.5,-0.03,"Bars above zero: outcomes happened more often than the price implied (underpriced). N=201.",
            ha="center",fontsize=6.7,color="#555")
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/fig_favlongshot.png",bbox_inches="tight",facecolor="white")
print("\nsaved fig_favlongshot.png")

# ---------- figure 4: ambiguity by category ----------
fig,ax=plt.subplots(figsize=(6.8,3.8),dpi=150)
cc=catg.reset_index()
ax.barh(cc["category"],cc["ambiguity"],color="#5b8c5a",edgecolor="white")
for i,r in cc.iterrows():
    ax.text(r["ambiguity"]+0.02,i,f"{r['ambiguity']:.2f}  (n={int(r['n'])})",va="center",fontsize=8,color="#444")
ax.set_xlabel("Mean resolution-rule ambiguity index",fontsize=10)
ax.set_title("Which markets have the most ambiguous rules?",fontsize=12,fontweight="bold",loc="left",pad=8)
for s in ["top","right"]: ax.spines[s].set_visible(False)
plt.tight_layout(); plt.savefig("/mnt/user-data/outputs/fig_ambiguity_by_cat.png",bbox_inches="tight",facecolor="white")
print("saved fig_ambiguity_by_cat.png")

# save the per-case table values
disp = mk[mk["disputed"]][["case","volumeNum","amb_pct","subj","obj"]].sort_values("amb_pct",ascending=False)
disp.to_csv("/home/claude/cases.csv",index=False)
print("\ncase table:\n", disp.to_string(index=False))
