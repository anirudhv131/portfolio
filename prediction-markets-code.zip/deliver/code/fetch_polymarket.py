#!/usr/bin/env python3
"""
fetch_polymarket.py  (v2 - fixed pagination)
--------------------------------------------
Downloads resolved Polymarket markets from the PUBLIC Gamma API.
No API key, no wallet, no login required.

v2 fix: pages correctly through results (v1 stopped after the first page),
and orders by volume DESC so the biggest / most important markets come first.

Usage:
  pip install requests
  python fetch_polymarket.py            # top ~6000 resolved markets by volume
  python fetch_polymarket.py --max 20000  # pull more if you want

Output: pm_data/pm_markets.csv  -> upload that back into the chat.
"""

import csv
import os
import sys
import time
import argparse

import requests

GAMMA = "https://gamma-api.polymarket.com"
OUTDIR = "pm_data"
HEADERS = {"User-Agent": "student-research/1.0 (academic use)"}
PAGE = 100  # Gamma caps page size around here; request 100 at a time

FIELDS = [
    "id", "question", "slug", "conditionId", "questionID",
    "description",        # resolution rule text (used to code ambiguity)
    "outcomes", "outcomePrices", "clobTokenIds",
    "volume", "volumeNum", "liquidity",
    "startDate", "endDate", "closedTime",
    "closed", "active", "archived",
    "umaBond", "umaReward", "resolvedBy", "resolutionSource",
    "umaResolutionStatus", "hasReviewedDates",
]


def get(url, params=None, tries=6):
    for i in range(tries):
        r = requests.get(url, params=params, headers=HEADERS, timeout=30)
        if r.status_code == 200:
            return r
        if r.status_code in (429, 500, 502, 503, 504):
            wait = 2 ** i
            print(f"  ({r.status_code}) backing off {wait}s...", file=sys.stderr)
            time.sleep(wait)
            continue
        r.raise_for_status()
    raise RuntimeError(f"failed after {tries} tries: {url}")


def fetch_markets(max_markets):
    os.makedirs(OUTDIR, exist_ok=True)
    out_path = os.path.join(OUTDIR, "pm_markets.csv")
    offset = 0
    total = 0
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        writer.writeheader()
        while total < max_markets:
            r = get(f"{GAMMA}/markets", params={
                "closed": "true",
                "limit": PAGE,
                "offset": offset,
                "order": "volumeNum",   # biggest markets first
                "ascending": "false",
            })
            batch = r.json()
            if not batch:           # <-- only stop when a page comes back EMPTY
                break
            for m in batch:
                writer.writerow({k: m.get(k, "") for k in FIELDS})
            got = len(batch)
            total += got
            offset += got
            print(f"  fetched {total} markets...", file=sys.stderr)
            time.sleep(0.3)
            if got < PAGE:          # last (partial) page reached
                break
    print(f"DONE -> {out_path}  ({total} markets)")
    return out_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max", type=int, default=6000,
                    help="max number of markets to pull (default 6000)")
    args = ap.parse_args()
    fetch_markets(args.max)


if __name__ == "__main__":
    main()
