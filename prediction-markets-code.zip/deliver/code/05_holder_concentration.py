import pandas as pd, numpy as np, json

H = pd.read_csv("/mnt/user-data/uploads/holders_detail.csv")
H["shares"] = pd.to_numeric(H["shares"], errors="coerce")
H = H.dropna(subset=["shares"])
H = H[H["shares"]>0]

mk = pd.read_csv("pm_scored.csv")
mk["conditionId"]=mk["conditionId"].astype(str)
# map asset token -> outcome index via clobTokenIds [yes, no]
def toks(s):
    try: return [str(x) for x in json.loads(s)]
    except: return []
mk["tok"]=mk["clobTokenIds"].apply(toks)
asset_to_idx={}
win_idx={}
for _,r in mk.iterrows():
    for i,t in enumerate(r["tok"]):
        asset_to_idx[(r["conditionId"],t)] = i
    # winning outcome index: yes_won=1 -> index0 wins; else index1
    yw=r.get("yes_won")
    win_idx[r["conditionId"]] = 0 if yw==1 else (1 if yw==0 else np.nan)

H["okey"]=H["outcome_key"].astype(str)
H["oidx"]=H.apply(lambda x: asset_to_idx.get((x["conditionId"],x["okey"]), np.nan), axis=1)
print("rows mapped to an outcome index:", H["oidx"].notna().sum(), "/", len(H))

def metrics(g):
    s=np.sort(g["shares"].values)[::-1]; tot=s.sum()
    if tot<=0 or len(s)==0: return pd.Series(dict(n=len(s),top1=np.nan,top5=np.nan,hhi=np.nan))
    sh=s/tot
    return pd.Series(dict(n=len(s), top1=sh[0], top5=sh[:5].sum(), hhi=(sh**2).sum()))

# concentration per market-outcome
co = H.dropna(subset=["oidx"]).groupby(["conditionId","oidx"]).apply(metrics).reset_index()
co["oidx"]=co["oidx"].astype(int)

# attach winning flag
co["is_win"]=co.apply(lambda r: win_idx.get(r["conditionId"])==r["oidx"], axis=1)
disp_ids=set(mk[mk["disputed"]]["conditionId"])
co["disputed"]=co["conditionId"].isin(disp_ids)

for side,lab in [(True,"WINNING side"),(False,"LOSING side")]:
    sub=co[co["is_win"]==side]
    d=sub[sub["disputed"]]; r=sub[~sub["disputed"]]
    print(f"\n=== {lab} concentration ===")
    print(f" disputed (n={len(d)}):  top1={d['top1'].mean():.3f}  top5={d['top5'].mean():.3f}  hhi={d['hhi'].mean():.3f}  holders={d['n'].mean():.0f}")
    print(f" others   (n={len(r)}):  top1={r['top1'].mean():.3f}  top5={r['top5'].mean():.3f}  hhi={r['hhi'].mean():.3f}  holders={r['n'].mean():.0f}")

print("\n=== the four disputed cases (winning side) ===")
cases=mk[mk["disputed"]][["case","conditionId"]]
for _,c in cases.iterrows():
    row=co[(co["conditionId"]==c["conditionId"])&(co["is_win"])]
    if len(row):
        rr=row.iloc[0]
        print(f"  {c['case']:24s} top1={rr['top1']:.2f} top5={rr['top5']:.2f} hhi={rr['hhi']:.2f} holders={int(rr['n'])}")
    else:
        print(f"  {c['case']:24s} (no winning-side holders found; likely redeemed)")
co.to_csv("/home/claude/concentration.csv",index=False)
print("\nsaved concentration.csv ; markets covered:", co['conditionId'].nunique())
