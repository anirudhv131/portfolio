import pandas as pd, numpy as np, json
np.random.seed(42)

mk = pd.read_csv("pm_scored.csv")
mk["conditionId"]=mk["conditionId"].astype(str)

# ---------- 1. permutation test on the ambiguity clustering ----------
pct = mk["amb_pct"].values/100.0           # uniform by construction
disp = mk[mk["disputed"]].sort_values("amb_pct")
disp_pct = (disp["amb_pct"].values/100.0)
obs_median = np.median(disp_pct)
# how many of the 4 are above the 73rd percentile
above73 = (disp_pct >= 0.73).sum()

N=200000
sims = np.random.choice(pct, size=(N,4), replace=True)
sim_median = np.median(sims, axis=1)
p_median = (sim_median >= obs_median).mean()
sim_above = (sims >= 0.73).sum(axis=1)
p_above = (sim_above >= above73).mean()
print("=== permutation test (ambiguity clustering) ===")
print(f" observed median percentile of 4 cases: {obs_median*100:.1f}")
print(f" P(random 4 have median >= {obs_median*100:.1f}): {p_median:.3f}")
print(f" cases at/above 73rd pct: {above73}/4")
print(f" P(>= {above73} of 4 random above 73rd pct): {p_above:.3f}")
print()

# ---------- 2. robustness of the ambiguity index to construction ----------
def pctl(col):
    r = mk[col].rank(pct=True)*100
    return r
mk["amb_subjonly"] = mk["subj"]
mk["amb_subjminusobj"] = mk["subj"] - mk["obj"]
for c in ["amb_subjonly","amb_subjminusobj"]:
    mk[c+"_pct"]=pctl(c)
print("=== ambiguity index robustness (percentile under variants) ===")
print(f"{'case':24s} {'main':>6} {'subj_only':>10} {'subj-obj':>9}")
for _,r in disp.iterrows():
    rr=mk[mk['conditionId']==r['conditionId']].iloc[0]
    print(f"{r['case']:24s} {rr['amb_pct']:6.0f} {rr['amb_subjonly_pct']:10.0f} {rr['amb_subjminusobj_pct']:9.0f}")
print()

# ---------- 3. calibration robustness: 24h vs 7d ----------
pr = pd.read_csv("/mnt/user-data/uploads/pm_prices_snapshot.csv")
for c in ["yes_won","p_24h_before","p_7d_before"]:
    pr[c]=pd.to_numeric(pr[c],errors="coerce")
def reg(d,xc):
    d=d.dropna(subset=[xc,"yes_won"]); x=d[xc].values;y=d["yes_won"].values;n=len(x)
    b,a=np.polyfit(x,y,1); yhat=a+b*x; s2=np.sum((y-yhat)**2)/(n-2)
    sxx=np.sum((x-x.mean())**2); seb=np.sqrt(s2/sxx); sea=np.sqrt(s2*(1/n+x.mean()**2/sxx))
    brier=np.mean((x-y)**2); base=y.mean(); brier0=np.mean((base-y)**2)
    return n,a,sea,b,seb,brier,1-brier/brier0
print("=== calibration robustness ===")
for xc,lab in [("p_24h_before","24h before"),("p_7d_before","7d before")]:
    n,a,sea,b,seb,brier,skill=reg(pr,xc)
    print(f" {lab:11s} N={n:4d}  a={a:.3f}({sea:.3f})  b={b:.3f}({seb:.3f})  Brier={brier:.3f}  skill={skill:+.2f}")
print()

# ---------- 4. Wilson intervals for calibration bins (24h) ----------
from math import sqrt
d=pr.dropna(subset=["p_24h_before","yes_won"]).copy()
bins=[0,.1,.2,.3,.4,.5,.6,.7,.8,.9,1.0001]
d["bin"]=pd.cut(d["p_24h_before"],bins,right=False)
def wilson(k,n,z=1.96):
    if n==0: return (np.nan,np.nan)
    p=k/n; den=1+z*z/n
    c=(p+z*z/(2*n))/den; half=z*sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return (c-half,c+half)
g=d.groupby("bin",observed=True).agg(n=("yes_won","size"),pred=("p_24h_before","mean"),real=("yes_won","mean")).reset_index()
g["lo"],g["hi"]=zip(*[wilson(int(r["real"]*r["n"]),int(r["n"])) for _,r in g.iterrows()])
g.to_csv("/home/claude/calib_bins.csv",index=False)
print("saved calib_bins.csv with Wilson intervals")
mk.to_csv("/home/claude/pm_scored2.csv",index=False)
