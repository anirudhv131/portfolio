import pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

df = pd.read_csv("/mnt/user-data/uploads/pm_prices_snapshot.csv")
for c in ["yes_won","p_24h_before","p_7d_before"]:
    df[c] = pd.to_numeric(df[c], errors="coerce")
# primary probability = price ~24h before close; fall back to 7d to maximize sample
df["p_pre"] = df["p_24h_before"].fillna(df["p_7d_before"])
d = df.dropna(subset=["p_pre","yes_won"]).copy()
N = len(d)
print("calibration sample N =", N)

# Brier score and a naive baseline (always predict base rate)
brier = np.mean((d["p_pre"]-d["yes_won"])**2)
base = d["yes_won"].mean()
brier_base = np.mean((base-d["yes_won"])**2)
print(f"Brier score (market) = {brier:.4f}")
print(f"Brier score (always base rate {base:.3f}) = {brier_base:.4f}")
print(f"skill score vs base = {1-brier/brier_base:.3f}  (positive = market beats naive)")
print()

# bin into probability buckets
bins = [0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0001]
d["bin"] = pd.cut(d["p_pre"], bins, right=False)
g = d.groupby("bin", observed=True).agg(
    n=("yes_won","size"), pred=("p_pre","mean"), realized=("yes_won","mean")
).reset_index()
print("=== calibration table ===")
for _,r in g.iterrows():
    print(f"  priced {r['pred']:.2f}  ->  won {r['realized']:.2f}   (n={int(r['n'])})")

# ---- figure: calibration curve ----
fig, ax = plt.subplots(figsize=(6.6,6.2), dpi=150)
ax.plot([0,1],[0,1], ls="--", color="#888", lw=1.2, label="perfect calibration", zorder=1)
sizes = (g["n"]/g["n"].max()*420)+30
ax.scatter(g["pred"], g["realized"], s=sizes, color="#3a6ea5",
           edgecolor="white", linewidth=1.2, zorder=3, label="Polymarket (binned)")
ax.plot(g["pred"], g["realized"], color="#3a6ea5", lw=1, alpha=.5, zorder=2)
for _,r in g.iterrows():
    ax.annotate(f"n={int(r['n'])}", (r["pred"], r["realized"]),
                textcoords="offset points", xytext=(6,-10), fontsize=6.5, color="#555")
ax.set_xlim(-0.02,1.02); ax.set_ylim(-0.02,1.02)
ax.set_xlabel("Market price ~24h before close (implied probability)", fontsize=10)
ax.set_ylabel("Fraction that actually happened", fontsize=10)
ax.set_title("The trading layer is well-calibrated", fontsize=12.5, fontweight="bold", loc="left", pad=10)
ax.text(0.02,0.93, f"N = {N} markets\nBrier = {brier:.3f}\nskill vs naive = {1-brier/brier_base:+.2f}",
        transform=ax.transAxes, fontsize=8.5, va="top",
        bbox=dict(boxstyle="round,pad=0.4", fc="#eef2f7", ec="#bcc"))
ax.legend(loc="lower right", fontsize=8, frameon=False)
for s in ["top","right"]: ax.spines[s].set_visible(False)
plt.figtext(0.5,-0.02,
  "Markets with retrievable order-book history (excludes pre-2022 markets). Points on the dashed line = "
  "prices that mean exactly what they say.", ha="center", fontsize=6.6, color="#555", wrap=True)
plt.tight_layout()
plt.savefig("/mnt/user-data/outputs/fig_calibration.png", bbox_inches="tight", facecolor="white")
print("\nsaved fig_calibration.png")
