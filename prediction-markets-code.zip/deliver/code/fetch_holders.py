#!/usr/bin/env python3
"""
fetch_holders.py  --  who holds each market (for the conflict-of-interest analysis)
-----------------------------------------------------------------------------------
Reads the pm_markets.csv you already have, and for each market pulls the top
holders of each outcome from Polymarket's PUBLIC Data API. No login, no key,
no Dune. This is the data that was paywalled on Dune; the public API gives it
for free.

It lets us measure, for the captured markets, whether the winning side was held
by a small concentrated group, and compare that to ordinary markets.

Usage:
  pip install requests pandas
  python fetch_holders.py            # all markets in pm_markets.csv (~8-10 min)
  python fetch_holders.py --max 400  # just the biggest 400 by volume (faster)

Outputs (in pm_data/):
  holders_detail.csv   -> one row per (market, holder): conditionId, outcome, wallet, shares
  holders_sample.json  -> the raw API response for one market, so the format can be verified

Writes as it goes; if you stop it early (Ctrl+C) the partial file is still usable.
"""

import csv, json, os, sys, time, argparse
import requests

DATA_API = "https://data-api.polymarket.com"
HEADERS = {"User-Agent": "student-research/1.0 (academic use)"}

# the four documented capture cases -- always included even if --max is small
DISPUTED = [
    "0x3733a1b647e7364095736ab0966465d896a84cf3b6bc1695ca1f26c3239b3868",
    "0x655e5ca101c466b6293aa15e06173b78b293221803d56e35551f708cd82eb352",
    "0x2865bc483dd523f4a36eb961f7467c8635ee9a13f39748bad55f645ce1f61512",
    "0x1663edea3eba0d1ae8f064276dd426cb0497a19bb5188dae48a2f8fa8ea34da8",
]


def find_csv(explicit):
    if explicit and os.path.exists(explicit):
        return explicit
    for c in ["pm_data/pm_markets.csv", "pm_markets.csv"]:
        if os.path.exists(c):
            return c
    sys.exit("Could not find pm_markets.csv. Pass it with --csv PATH")


def get(url, params, tries=5):
    for i in range(tries):
        try:
            r = requests.get(url, params=params, headers=HEADERS, timeout=30)
        except requests.RequestException:
            time.sleep(2 ** i); continue
        if r.status_code == 200:
            return r
        if r.status_code in (429, 500, 502, 503, 504):
            time.sleep(2 ** i); continue
        return None
    return None


def extract_holders(payload):
    """
    Normalize the /holders response into (outcome_key, wallet, shares) tuples.
    The endpoint returns, per outcome token, a list of top holders. We handle a
    few possible shapes defensively.
    """
    out = []
    def grab_amount(h):
        for k in ("amount", "shares", "size", "balance", "tokens"):
            if k in h and h[k] is not None:
                try: return float(h[k])
                except: pass
        return None
    # shape A: list of {token/asset, holders:[...]}
    if isinstance(payload, list) and payload and isinstance(payload[0], dict) and "holders" in payload[0]:
        for grp in payload:
            okey = str(grp.get("token") or grp.get("asset") or grp.get("outcomeIndex") or "")
            for h in grp.get("holders", []):
                w = h.get("proxyWallet") or h.get("wallet") or h.get("address")
                amt = grab_amount(h)
                if w is not None:
                    out.append((okey, w, amt))
        return out
    # shape B: {holders:[...]} or flat list of holder dicts
    flat = payload.get("holders") if isinstance(payload, dict) else payload
    if isinstance(flat, list):
        for h in flat:
            if not isinstance(h, dict): continue
            w = h.get("proxyWallet") or h.get("wallet") or h.get("address")
            okey = str(h.get("token") or h.get("asset") or h.get("outcomeIndex") or "")
            amt = grab_amount(h)
            if w is not None:
                out.append((okey, w, amt))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv")
    ap.add_argument("--max", type=int, default=10**9)
    args = ap.parse_args()

    src = find_csv(args.csv)
    os.makedirs("pm_data", exist_ok=True)
    out_path = "pm_data/holders_detail.csv"

    import pandas as pd
    df = pd.read_csv(src)
    df["volumeNum"] = pd.to_numeric(df["volumeNum"], errors="coerce").fillna(0)
    df = df.sort_values("volumeNum", ascending=False)

    cids = list(dict.fromkeys(DISPUTED + df["conditionId"].dropna().astype(str).tolist()))
    cids = cids[:max(args.max, len(DISPUTED))]
    qmap = dict(zip(df["conditionId"].astype(str), df["question"].astype(str)))

    saved_sample = False
    done = 0
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["conditionId", "question", "outcome_key", "wallet", "shares"])
        for cid in cids:
            r = get(f"{DATA_API}/holders", {"market": cid, "limit": 50})
            if r is None:
                done += 1; continue
            try:
                payload = r.json()
            except Exception:
                done += 1; continue
            if not saved_sample and payload:
                json.dump(payload, open("pm_data/holders_sample.json", "w"), indent=2)
                saved_sample = True
            for okey, wallet, shares in extract_holders(payload):
                w.writerow([cid, qmap.get(cid, "")[:100], okey, wallet, shares])
            f.flush()
            done += 1
            if done % 50 == 0:
                print(f"  processed {done}/{len(cids)} markets...", file=sys.stderr)
            time.sleep(0.25)
    print(f"DONE -> {out_path}  ({done} markets processed)")


if __name__ == "__main__":
    main()
