import pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

df = pd.read_csv("pm_scored.csv")
disp = df[df["disputed"]].sort_values("ambiguity")

fig, ax = plt.subplots(figsize=(8,4.6), dpi=150)
# distribution of ambiguity for all markets
ax.hist(df["ambiguity"], bins=40, color="#c9d3e0", edgecolor="white", linewidth=.4)
ax.set_xlabel("Resolution-rule ambiguity index", fontsize=10)
ax.set_ylabel("Number of markets", fontsize=10)
ax.set_title("Documented resolution-capture cases cluster in the ambiguous tail",
             fontsize=11.5, fontweight="bold", loc="left", pad=12)

# mark the disputed cases
ymax = ax.get_ylim()[1]
colors = ["#d1495b","#e07a3f","#c9a227","#3a6ea5"]
for i,(_,r) in enumerate(disp.iterrows()):
    x = r["ambiguity"]
    ax.axvline(x, color=colors[i%4], lw=1.4, alpha=.9)
    ax.text(x, ymax*(0.92-0.11*i), f"  {r['case']} ({r['amb_pct']:.0f}th pct)",
            color=colors[i%4], fontsize=8.3, fontweight="bold", va="top")

med = df["ambiguity"].median()
ax.axvline(med, color="#666", lw=1, ls="--")
ax.text(med, ymax*0.02, " median market", color="#666", fontsize=7.5, style="italic")

for s in ["top","right"]: ax.spines[s].set_visible(False)
ax.spines["left"].set_color("#999"); ax.spines["bottom"].set_color("#999")
plt.figtext(0.5,-0.04,
    "2,100 highest-volume resolved Polymarket markets. Ambiguity index = subjective resolution terms "
    "− 0.5×objective anchors + 0.25×edge-case clauses.\nDisputed cases are the four documented "
    "governance-attack markets (2025). n=4 is illustrative, not statistically powered.",
    ha="center", fontsize=6.6, color="#555")
plt.tight_layout()
plt.savefig("/mnt/user-data/outputs/fig_ambiguity.png", bbox_inches="tight", facecolor="white")
print("saved fig_ambiguity.png")
