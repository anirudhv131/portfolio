import pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
g=pd.read_csv("calib_bins.csv")
fig,ax=plt.subplots(figsize=(6.6,6.2),dpi=150)
ax.plot([0,1],[0,1],ls="--",color="#888",lw=1.2,label="perfect calibration",zorder=1)
yerr=[g["real"]-g["lo"], g["hi"]-g["real"]]
ax.errorbar(g["pred"],g["real"],yerr=yerr,fmt="o",color="#3a6ea5",ecolor="#9bb4cf",
            elinewidth=1.4,capsize=3,markersize=7,markeredgecolor="white",zorder=3,label="Polymarket (95% CI)")
for _,r in g.iterrows():
    ax.annotate(f"n={int(r['n'])}",(r["pred"],r["real"]),textcoords="offset points",xytext=(7,-11),fontsize=6.5,color="#555")
ax.set_xlim(-0.02,1.02);ax.set_ylim(-0.05,1.05)
ax.set_xlabel("Market price ~24h before close (implied probability)",fontsize=10)
ax.set_ylabel("Fraction that actually happened",fontsize=10)
ax.set_title("The trading layer is well calibrated",fontsize=12.5,fontweight="bold",loc="left",pad=10)
ax.text(0.02,0.93,"N = 201 markets\nBrier = 0.145\nslope = 0.94 (SE 0.08)\nintercept = 0.05 (SE 0.04)",
        transform=ax.transAxes,fontsize=8.3,va="top",bbox=dict(boxstyle="round,pad=0.4",fc="#eef2f7",ec="#bcc"))
ax.legend(loc="lower right",fontsize=8,frameon=False)
for s in ["top","right"]: ax.spines[s].set_visible(False)
plt.figtext(0.5,-0.02,"Error bars are 95% Wilson intervals. Markets with retrievable order-book history (excludes pre-2022 markets).",
            ha="center",fontsize=6.6,color="#555")
plt.tight_layout();plt.savefig("/mnt/user-data/outputs/fig_calibration.png",bbox_inches="tight",facecolor="white")
print("updated fig_calibration.png with Wilson intervals")
