import pandas as pd, json, re, numpy as np

df = pd.read_csv("/mnt/user-data/uploads/pm_markets.csv")
df["q"] = df["question"].astype(str)
df["desc"] = df["description"].astype(str)

# --- realized outcome (Yes=1 if first price settled to 1) ---
def p0(s):
    try: return float(json.loads(s)[0])
    except: return np.nan
df["yes_won"] = df["outcomePrices"].apply(p0)

# --- transparent, auditable ambiguity index over the resolution rule text ---
# Subjective / discretionary language = harder to verify objectively -> more capturable
SUBJECTIVE = [
    r"credible", r"consensus", r"widely (?:reported|accepted|considered)",
    r"generally", r"reasonabl", r"discretion", r"ambiguous", r"unclear",
    r"interpret", r"spirit of", r"judg(?:e|ment)", r"subjective", r"deemed",
    r"in the event of (?:any )?(?:dispute|ambiguity)", r"good faith",
    r"primary consideration", r"resolver", r"common sense",
]
# Objective anchors = a hard source the truth can be checked against -> less capturable
OBJECTIVE = [
    r"according to", r"official", r"https?://", r"associated press", r"\bAP\b",
    r"reuters", r"federal reserve", r"\bFED\b", r"data\.bls", r"announce",
    r"press release", r"certified", r"final result", r"exactly", r"\d+\s?%",
    r"closing price", r"on-chain", r"blockchain",
]

def count(patterns, text):
    t = text.lower()
    return sum(len(re.findall(p, t)) for p in patterns)

df["subj"] = df["desc"].apply(lambda t: count(SUBJECTIVE, t))
df["obj"]  = df["desc"].apply(lambda t: count(OBJECTIVE, t))
# ambiguity index: more subjective language, fewer objective anchors, longer/edge-case-laden text
df["edge_cases"] = df["desc"].str.lower().str.count("if ") + df["desc"].str.lower().str.count("however")
df["ambiguity"] = df["subj"] - 0.5*df["obj"] + 0.25*df["edge_cases"]

# --- label the documented disputed/capture cases present in the file ---
DISPUTED = {
    "Ukraine mineral deal": r"ukraine agrees to trump mineral deal",
    "Zelensky suit": r"zelensky+y? wear a suit",
    "MicroStrategy BTC (May)": r"microstrategy sells any bitcoin by may 31, 2026",
    "UFO declassification": r"trump declassifies ufo files in 2025",
}
df["disputed"] = False
df["case"] = ""
for name, pat in DISPUTED.items():
    m = df["q"].str.contains(pat, case=False, regex=True, na=False)
    df.loc[m, "disputed"] = True
    df.loc[m, "case"] = name

n_disp = df["disputed"].sum()
print(f"documented disputed cases located in file: {n_disp}")
print()

# --- the core comparison ---
df["amb_pct"] = df["ambiguity"].rank(pct=True)*100
disp = df[df["disputed"]]
rest = df[~df["disputed"]]
print("=== AMBIGUITY: disputed vs the rest ===")
print(f"disputed   mean ambiguity = {disp['ambiguity'].mean():.2f}  (n={len(disp)})")
print(f"all others mean ambiguity = {rest['ambiguity'].mean():.2f}  (n={len(rest)})")
print()
# where do disputed markets rank in the full ambiguity distribution?
print("=== each disputed market's ambiguity percentile (100 = most ambiguous in dataset) ===")
for _,r in disp.sort_values("ambiguity",ascending=False).iterrows():
    print(f"  {r['case']:26s} pct={r['amb_pct']:5.1f}   subj={r['subj']} obj={r['obj']} edge={r['edge_cases']}  | {r['q'][:45]}")
print()
print(f"median ambiguity percentile of disputed cases: {disp['amb_pct'].median():.1f}")
print(f"(a random market would average 50.0)")

df.to_csv("/home/claude/pm_scored.csv", index=False)
print("\nsaved scored dataset -> pm_scored.csv")