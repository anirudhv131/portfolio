#!/usr/bin/env python3
"""
fetch_prices.py  --  pulls pre-resolution prices for calibration
-----------------------------------------------------------------
Reads the pm_markets.csv you already downloaded, and for each YES/NO market
fetches its price history from Polymarket's PUBLIC CLOB API (no key needed),
then records the market's price 24h and 7d before it resolved, plus the last
price -- paired with what actually happened.

This is exactly what's needed to test calibration:
   "of markets the crowd priced at 70%, did ~70% actually happen?"

Usage:
  pip install requests pandas
  python fetch_prices.py                 # processes pm_data/pm_markets.csv
  python fetch_prices.py --csv pm_markets.csv     # if the file is elsewhere
  python fetch_prices.py --max 800       # cap how many (default: all of them)

Output: pm_data/pm_prices_snapshot.csv   -> upload that back into the chat.

Notes:
  * It writes as it goes, so if you stop it early (Ctrl+C) the partial file
    is still usable -- just upload what you've got.
  * ~2,100 markets takes roughly 10-15 minutes. That's normal.
"""

import csv, json, os, sys, time, argparse
from datetime import datetime, timezone
import requests

CLOB = "https://clob.polymarket.com"
HEADERS = {"User-Agent": "student-research/1.0 (academic use)"}


def find_csv(explicit):
    if explicit and os.path.exists(explicit):
        return explicit
    for c in ["pm_data/pm_markets.csv", "pm_markets.csv"]:
        if os.path.exists(c):
            return c
    sys.exit("Could not find pm_markets.csv. Pass it with --csv PATH")


def get(url, params, tries=5):
    for i in range(tries):
        try:
            r = requests.get(url, params=params, headers=HEADERS, timeout=30)
        except requests.RequestException:
            time.sleep(2 ** i); continue
        if r.status_code == 200:
            return r
        if r.status_code in (429, 500, 502, 503, 504):
            time.sleep(2 ** i); continue
        return None
    return None


def to_ts(s):
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp()
    except Exception:
        return None


def first_json(s):
    try:
        return json.loads(s)
    except Exception:
        return None


def price_at(history, target_ts):
    """price of the last point at or before target_ts."""
    best = None
    for pt in history:
        t = pt.get("t")
        if t is None:
            continue
        if t <= target_ts:
            best = pt.get("p")
        else:
            break
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv")
    ap.add_argument("--max", type=int, default=10**9)
    args = ap.parse_args()

    src = find_csv(args.csv)
    os.makedirs("pm_data", exist_ok=True)
    out = "pm_data/pm_prices_snapshot.csv"

    rows = list(csv.DictReader(open(src, encoding="utf-8")))
    done = 0
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["conditionId", "question", "volumeNum", "endDate",
                    "yes_won", "p_24h_before", "p_7d_before", "p_last"])
        for m in rows:
            if done >= args.max:
                break
            outcomes = first_json(m.get("outcomes", ""))
            tokens = first_json(m.get("clobTokenIds", ""))
            prices = first_json(m.get("outcomePrices", ""))
            # keep clean binary Yes/No markets only
            if not (outcomes and tokens and prices):
                continue
            if [str(o).lower() for o in outcomes[:2]] != ["yes", "no"]:
                continue
            end_ts = to_ts(m.get("endDate"))
            if end_ts is None:
                continue
            yes_token = str(tokens[0])
            try:
                yes_won = int(round(float(prices[0])))
            except Exception:
                continue

            r = get(f"{CLOB}/prices-history",
                    {"market": yes_token, "interval": "max", "fidelity": 60})
            hist = []
            if r is not None:
                try:
                    hist = r.json().get("history", [])
                except Exception:
                    hist = []
            hist = [h for h in hist if "t" in h and "p" in h]
            hist.sort(key=lambda x: x["t"])

            p24 = price_at(hist, end_ts - 24 * 3600) if hist else ""
            p7d = price_at(hist, end_ts - 7 * 24 * 3600) if hist else ""
            plast = hist[-1]["p"] if hist else ""

            w.writerow([m.get("conditionId", ""), m.get("question", "")[:120],
                        m.get("volumeNum", ""), m.get("endDate", ""),
                        yes_won, p24, p7d, plast])
            f.flush()
            done += 1
            if done % 50 == 0:
                print(f"  processed {done} markets...", file=sys.stderr)
            time.sleep(0.25)

    print(f"DONE -> {out}  ({done} markets with prices)")


if __name__ == "__main__":
    main()
